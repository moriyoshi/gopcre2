package jit

import (
	p "github.com/KarpelesLab/gopcre2"
	n "github.com/moriyoshi/nyanjit"
	"github.com/moriyoshi/nyanjit/ir"
)

func (c *emitter) checkCharacter(e *p.Expression, fail n.Label) {
	b := c.b
	c.tick()
	pos := b.Get(c.pos)
	b.Branch(b.Compare(pos, ir.BranchAboveEqual, c.end), fail)
	ch := c.charAt(pos)
	if e.Kind() == p.NdDot && e.Flags()&p.DotAll == 0 && c.flags&p.NewlineCRLF != 0 {
		checkLF, done := b.NewLabel(), b.NewLabel()
		b.Branch(b.CompareImmediate(ch, ir.BranchNotEqual, '\r'), checkLF)
		b.Branch(b.Compare(b.Add(pos, b.ConstNative(1)), ir.BranchAboveEqual, c.end), done)
		b.Branch(b.CompareImmediate(c.charAt(b.Add(pos, b.ConstNative(1))), ir.BranchEqual, '\n'), fail, done)
		b.Bind(checkLF)
		b.Branch(b.CompareImmediate(ch, ir.BranchNotEqual, '\n'), done)
		b.Branch(b.CompareImmediate(pos, ir.BranchEqual, 0), done)
		b.Branch(b.CompareImmediate(c.charAt(b.Sub(pos, b.ConstNative(1))), ir.BranchEqual, '\r'), fail, done)
		b.Bind(done)
	}
	var set [128]bool
	for i := range set {
		r := rune(i)
		switch e.Kind() {
		case p.NdLiteral:
			set[i] = r == e.Rune()
		case p.NdCharClass:
			for j := 0; j < e.NumRanges(); j++ {
				rr := e.Range(j)
				set[i] = set[i] || (r >= rr.Lo && r <= rr.Hi)
			}
		case p.NdDot:
			set[i] = true
			if e.Flags()&p.DotAll == 0 {
				switch {
				case c.flags&p.NewlineNUL != 0:
					set[i] = r != 0
				case c.flags&p.NewlineCR != 0:
					set[i] = r != '\r'
				case c.flags&p.NewlineCRLF != 0: // handled with neighboring bytes above
				case c.flags&p.NewlineAny != 0:
					set[i] = r < '\n' || r > '\r'
				case c.flags&p.NewlineAnyCRLF != 0:
					set[i] = r != '\r' && r != '\n'
				default:
					set[i] = r != '\n'
				}
			}
		case p.NdCharType:
			switch e.CharType() {
			case p.CharTypeDigit, p.CharTypeNonDigit:
				set[i] = r >= '0' && r <= '9'
			case p.CharTypeWord, p.CharTypeNonWord:
				set[i] = (r >= '0' && r <= '9') || (r >= 'A' && r <= 'Z') || (r >= 'a' && r <= 'z') || r == '_'
			case p.CharTypeSpace, p.CharTypeNonSpace:
				set[i] = r == ' ' || (r >= '\t' && r <= '\r')
			case p.CharTypeHSpace, p.CharTypeNonHSpace:
				set[i] = r == ' ' || r == '\t'
			case p.CharTypeVSpace, p.CharTypeNonVSpace:
				set[i] = r >= '\n' && r <= '\r'
			}
			if e.CharType()%2 == 1 {
				set[i] = !set[i]
			}
		}
	}
	if e.Flags()&p.Caseless != 0 && (e.Kind() == p.NdLiteral || e.Kind() == p.NdCharClass) {
		for i := int('A'); i <= int('Z'); i++ {
			both := set[i] || set[i+32]
			set[i] = both
			set[i+32] = both
		}
	}
	if e.Kind() == p.NdCharClass && e.Negated() {
		for i := range set {
			set[i] = !set[i]
		}
	}
	pred := b.CompareImmediate(ch, ir.BranchBelow, 0)
	for i := 0; i < len(set); i++ {
		if !set[i] {
			continue
		}
		lo := i
		for i+1 < len(set) && set[i+1] {
			i++
		}
		part := b.CompareImmediate(ch, ir.BranchEqual, int64(lo))
		if i > lo {
			part = b.CompareImmediate(ch, ir.BranchAboveEqual, int64(lo)).And(b.CompareImmediate(ch, ir.BranchBelowEqual, int64(i)))
		}
		pred = pred.Or(part)
	}
	b.Branch(pred.Not(), fail)
}

func (c *emitter) beginLine(flags p.Flag, fail n.Label) {
	b := c.b
	pass := b.NewLabel()
	pos := b.Get(c.pos)
	b.Branch(b.CompareImmediate(pos, ir.BranchEqual, 0), pass)
	if flags&p.Multiline == 0 {
		b.Jump(fail)
	} else {
		// ^ does not match the empty line after a final newline by default.
		b.Branch(b.Compare(pos, ir.BranchAboveEqual, c.end), fail)
		prev := c.charAt(b.Sub(pos, b.ConstNative(1)))
		switch {
		case c.flags&p.NewlineNUL != 0:
			b.Branch(b.CompareImmediate(prev, ir.BranchEqual, 0), pass, fail)
		case c.flags&p.NewlineCR != 0:
			b.Branch(b.CompareImmediate(prev, ir.BranchEqual, '\r'), pass, fail)
		case c.flags&p.NewlineCRLF != 0:
			b.Branch(b.CompareImmediate(prev, ir.BranchNotEqual, '\n'), fail)
			b.Branch(b.CompareImmediate(pos, ir.BranchBelow, 2), fail)
			b.Branch(b.CompareImmediate(c.charAt(b.Sub(pos, b.ConstNative(2))), ir.BranchEqual, '\r'), pass, fail)
		case c.crlf():
			b.Branch(b.CompareImmediate(prev, ir.BranchEqual, '\n'), pass)
			if c.flags&p.NewlineAny != 0 {
				b.Branch(b.CompareImmediate(prev, ir.BranchAboveEqual, '\v').And(b.CompareImmediate(prev, ir.BranchBelowEqual, '\f')), pass)
			}
			b.Branch(b.CompareImmediate(prev, ir.BranchNotEqual, '\r'), fail)
			b.Branch(b.CompareImmediate(c.charAt(pos), ir.BranchNotEqual, '\n'), pass, fail)
		default:
			b.Branch(b.CompareImmediate(prev, ir.BranchEqual, '\n'), pass, fail)
		}
	}
	b.Bind(pass)
}

func (c *emitter) endLine(flags p.Flag, forceOptional bool, fail n.Label) {
	b := c.b
	pass := b.NewLabel()
	pos := b.Get(c.pos)
	b.Branch(b.Compare(pos, ir.BranchEqual, c.end), pass)
	if !forceOptional && flags&p.Multiline == 0 && flags&p.DollarEndOnly != 0 {
		b.Jump(fail)
		b.Bind(pass)
		return
	}
	one, pair := b.NewLabel(), b.NewLabel()
	ch := c.charAt(pos) // pos <= end is an invariant; end was excluded above.
	switch {
	case c.flags&p.NewlineNUL != 0:
		b.Branch(b.CompareImmediate(ch, ir.BranchEqual, 0), one, fail)
	case c.flags&p.NewlineCR != 0:
		b.Branch(b.CompareImmediate(ch, ir.BranchEqual, '\r'), one, fail)
	case c.crlf():
		lf := b.NewLabel()
		b.Branch(b.CompareImmediate(ch, ir.BranchNotEqual, '\r'), lf)
		if c.flags&p.NewlineCRLF == 0 {
			b.Branch(b.Compare(b.Add(pos, b.ConstNative(1)), ir.BranchEqual, c.end), one)
		} else {
			b.Branch(b.Compare(b.Add(pos, b.ConstNative(1)), ir.BranchAboveEqual, c.end), fail)
		}
		b.Branch(b.CompareImmediate(c.charAt(b.Add(pos, b.ConstNative(1))), ir.BranchEqual, '\n'), pair)
		if c.flags&p.NewlineCRLF != 0 {
			b.Jump(fail)
		} else {
			b.Jump(one)
		}
		b.Bind(lf)
		if c.flags&p.NewlineAny != 0 {
			b.Branch(b.CompareImmediate(ch, ir.BranchAboveEqual, '\v').And(b.CompareImmediate(ch, ir.BranchBelowEqual, '\f')), one)
		}
		b.Branch(b.CompareImmediate(ch, ir.BranchNotEqual, '\n'), fail)
		if c.flags&p.NewlineCRLF != 0 {
			b.Jump(fail)
		} else {
			b.Branch(b.CompareImmediate(pos, ir.BranchEqual, 0), one)
			b.Branch(b.CompareImmediate(c.charAt(b.Sub(pos, b.ConstNative(1))), ir.BranchNotEqual, '\r'), one, fail)
		}
	default:
		b.Branch(b.CompareImmediate(ch, ir.BranchEqual, '\n'), one, fail)
	}
	b.Bind(pair)
	if flags&p.Multiline == 0 {
		b.Branch(b.Compare(b.Add(pos, b.ConstNative(2)), ir.BranchNotEqual, c.end), fail)
	}
	b.Jump(pass)
	b.Bind(one)
	if flags&p.Multiline == 0 {
		b.Branch(b.Compare(b.Add(pos, b.ConstNative(1)), ir.BranchNotEqual, c.end), fail)
	}
	b.Jump(pass)
	b.Bind(pass)
}
