package gopcre2

import "strings"

func (re *Regexp) MatchPHP(subject string, start int, anchored, notEmptyAtStart bool) ([]int, error) {
	if start < 0 || start > len(subject) {
		return nil, nil
	}
	if re.flags&NoStartOptimize == 0 && len(subject)-start < re.prog.MinLen {
		return nil, nil
	}
	var v *vm
	try := func(pos int) bool {
		if v == nil {
			v = re.newMatchVM(subject, pos)
			v.notEmptyAtStart = notEmptyAtStart
			v.searchStart = start
		} else {
			v.resetAttempt(pos)
		}
		v.startPos = start
		return v.exec()
	}
	result := func() ([]int, error) {
		out := make([]int, len(v.captures))
		copy(out, v.captures)
		return out, nil
	}
	if anchored || re.prog.AnchorStart {
		if try(start) {
			return result()
		}
		return nil, v.limitErr
	}
	if re.flags&NoStartOptimize == 0 && len(re.prog.Prefix) > 1 {
		i := start
		for {
			idx := strings.Index(subject[i:], re.prog.Prefix)
			if idx < 0 {
				if v != nil {
					return nil, v.limitErr
				}
				return nil, nil
			}
			pos := i + idx
			if try(pos) {
				return result()
			}
			if v.limitErr != nil {
				return nil, v.limitErr
			}
			if pos >= len(subject) {
				return nil, nil
			}
			_, size := decodeCharacter(subject[pos:], re.flags)
			i = pos + size
		}
	}
	for i := start; i <= len(subject); {
		if try(i) {
			return result()
		}
		if v.limitErr != nil {
			return nil, v.limitErr
		}
		if i >= len(subject) {
			break
		}
		_, size := decodeCharacter(subject[i:], re.flags)
		i += size
	}
	return nil, nil
}
